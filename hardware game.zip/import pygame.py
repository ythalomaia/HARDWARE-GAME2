import pygame
import sys
import random

from testes import run_game

pygame.init()
Largura = 1100
Altura = 600

pygame.mixer.music.load("musicas/ppa musica.mp3")  # música
pygame.mixer.music.play(-1)

click = pygame.mixer.Sound("musicas/click.mp3")  # efeito
c = pygame.mixer.Sound("musicas/acerto.mp3")


som_de_click_ativo = True

global ponto
ponto = 0

global ponto1d
ponto1 = 0

global ponto2
ponto2 = 0

global mistaaah1
mistaaah1 = 0

global mistaaah2
mistaaah2 = 0

global mistaaah3
mistaaah3 = 0
def janela1():
    janela_de_play = pygame.display.set_mode((Largura, Altura))
    pygame.display.set_caption("janela play")

    imagem = pygame.image.load("telas/tela1.png")
    imagem = pygame.transform.scale(imagem, (Largura, Altura))

    janela_de_play.blit(imagem, (0, 0))

    botao_play = pygame.image.load("invisible.png")
    botao_menu = pygame.image.load("invisible.png")
    botao_icone = pygame.image.load("invisible.png")

    botao_play_pos = pygame.Rect(400, 400, 300, 130)
    botao_menu_pos = pygame.Rect(400, 250, 300, 100)
    botao_icone_pos = pygame.Rect(100, 350, 200, 200)

    botao_play = pygame.transform.scale(botao_play, (300, 160))
    botao_menu = pygame.transform.scale(botao_menu, (300, 130))
    botao_icone = pygame.transform.scale(botao_icone, (200, 200))

    janela_de_play.blit(botao_play, botao_play_pos)
    janela_de_play.blit(botao_menu, botao_menu_pos)
    janela_de_play.blit(botao_icone, botao_icone_pos)

    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif event.type == pygame.MOUSEBUTTONDOWN:
                if botao_play_pos.collidepoint(event.pos):
                    if som_de_click_ativo:
                        click.play()
                    janela2()
                elif botao_menu_pos.collidepoint(event.pos):
                    if som_de_click_ativo:
                        click.play()
                    janela3()
                elif botao_icone_pos.collidepoint(event.pos):
                    if som_de_click_ativo:
                        click.play()
                    janela_de_creditos()

        pygame.display.update()


def janela2():
    tela_de_nivel = pygame.display.set_mode((Largura, Altura))
    pygame.display.set_caption("janela nível")

    imagem = pygame.image.load("telas/tela2.png")
    imagem = pygame.transform.scale(imagem, (Largura, Altura))

    tela_de_nivel.blit(imagem, (0, 0))

    botao_voltar = pygame.image.load("invisible.png")
    botao_menu2 = pygame.image.load("invisible.png")
    botao_quiz = pygame.image.load("invisible.png")
    botao_jogo_ythalo = pygame.image.load("invisible.png")

    botao_voltar_pos = pygame.Rect(0, 520, 130, 80)
    botao_menu2_pos = pygame.Rect(1000, 0, 100, 80)
    botao_quiz_pos = pygame.Rect(150, 220, 220, 110)
    botao_jogo_ythalo_pos = pygame.Rect(670, 220, 220, 100)

    botao_voltar = pygame.transform.scale(botao_voltar, (130, 90))
    botao_menu2 = pygame.transform.scale(botao_menu2, (130, 80))
    botao_quiz = pygame.transform.scale(botao_quiz, (220, 115))
    botao_jogo_ythalo = pygame.transform.scale(botao_jogo_ythalo, (220, 115))

    tela_de_nivel.blit(botao_menu2, botao_menu2_pos)
    tela_de_nivel.blit(botao_voltar, botao_voltar_pos)
    tela_de_nivel.blit(botao_quiz, botao_quiz_pos)
    tela_de_nivel.blit(botao_jogo_ythalo, botao_jogo_ythalo_pos)

    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif event.type == pygame.MOUSEBUTTONDOWN:
                if botao_voltar_pos.collidepoint(event.pos):
                    if som_de_click_ativo:
                        click.play()
                    janela1()
                elif botao_menu2_pos.collidepoint(event.pos):
                    if som_de_click_ativo:
                        click.play()
                    janela3()
                elif botao_quiz_pos.collidepoint(event.pos):
                    if som_de_click_ativo:
                        click.play()
                    menu_do_quiz()
                elif botao_jogo_ythalo_pos.collidepoint(event.pos):
                    if som_de_click_ativo:
                        click.play()
                    jogo_ytthalo()

        pygame.display.update()


def menu_do_quiz():
    tela_menu_do_quiz = pygame.display.set_mode((Largura, Altura))
    pygame.display.set_caption("menu do quiz")

    imagem = pygame.image.load("telas/menu de quiz.png")

    imagem = pygame.transform.scale(imagem, (Largura, Altura))

    tela_menu_do_quiz.blit(imagem, (0, 0))

    botao_voltar = pygame.image.load("invisible.png")
    botao_nivel1 = pygame.image.load("invisible.png")
    botao_nivel2 = pygame.image.load("invisible.png")
    botao_nivel3 = pygame.image.load("invisible.png")

    botao_voltar_pos = pygame.Rect(5, 520, 170, 150)
    botao_nivel1_pos = pygame.Rect(180, 170, 120, 120)
    botao_nivel2_pos = pygame.Rect(500, 340, 120, 120)
    botao_nivel3_pos = pygame.Rect(780, 170, 120, 120)

    botao_voltar = pygame.transform.scale(botao_voltar, (170, 150))
    botao_nivel1 = pygame.transform.scale(botao_nivel1, (120, 120))
    botao_nivel2 = pygame.transform.scale(botao_nivel2, (120, 120))
    botao_nivel3 = pygame.transform.scale(botao_nivel3, (120, 120))

    tela_menu_do_quiz.blit(botao_voltar, botao_voltar_pos)
    tela_menu_do_quiz.blit(botao_nivel1, botao_nivel1_pos)
    tela_menu_do_quiz.blit(botao_nivel2, botao_nivel2_pos)
    tela_menu_do_quiz.blit(botao_nivel3, botao_nivel3_pos)
    global ponto
    global mistaaah1
    mistaaah1 = ponto // 10
    global mistaaah2
    mistaaah2 = ponto1 // 10
    print (mistaaah1)
    print (mistaaah2)
    global mistaaah3
    mistaaah3 = ponto2 // 10
    print (mistaaah3)

    BRANCO = (255, 255, 255)
    fonte = pygame.font.Font('arial.ttf', 56)
    superficie_do_numero2 = fonte.render(str(mistaaah1), True, BRANCO)
    tela_menu_do_quiz.blit(superficie_do_numero2, (220, 323))
    
    superficie_do_numero3 = fonte.render(str(mistaaah2), True, BRANCO)
    tela_menu_do_quiz.blit(superficie_do_numero3, (520, 250))

    superficie_do_numero4 = fonte.render(str(mistaaah3), True, BRANCO)
    tela_menu_do_quiz.blit(superficie_do_numero4, (830, 327))

    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif event.type == pygame.MOUSEBUTTONDOWN:
                if botao_voltar_pos.collidepoint(event.pos):
                    if som_de_click_ativo:
                        click.play()
                    janela2()
                elif event.type == pygame.MOUSEBUTTONDOWN:
                    if botao_nivel1_pos.collidepoint(event.pos):
                        if som_de_click_ativo:
                            click.play()
                        fase01()
                    elif event.type == pygame.MOUSEBUTTONDOWN:
                        if botao_nivel2_pos.collidepoint(event.pos):
                            if som_de_click_ativo:
                                click.play()
                            fase02()
                        elif event.type == pygame.MOUSEBUTTONDOWN:
                            if botao_nivel3_pos.collidepoint(event.pos):
                                if som_de_click_ativo:
                                    click.play()
                                fase03()

        pygame.display.update()


def jogo_ytthalo():
    # Função para criar um novo tiro
    def restart_game():
        # Reinicializa as variáveis do jogo
        global player_x, player_y, player_speed, obstacles, bullet_speed, bullet_damage, game_over, restart_button_rect

        player_x = (screen_width - player_width) // 2
        player_y = (screen_height - player_height) // 2
        player_speed = 10
        obstacles = []
        for _ in range(num_obstacles):
            obstacle_x = random.randint(0, screen_width - obstacle_width)
            obstacle_y = random.randint(-screen_height, 0)
            obstacles.append([obstacle_image, obstacle_x, obstacle_y, random.choice(obstacle_health)])
        bullet_speed = 15
        bullet_damage = [15, 50, 25]
        game_over = False

        run_game()

        # Função para criar um novo tiro

    def fire_bullet(x, y):
        bullets.append([bullet_image, x, y])

        # Função para mostrar a tela de contagem regressiva

    def countdown_screen():
        countdown_font = pygame.font.Font(None, 150)
        for i in range(3, 0, -1):
            screen.fill(black)
            countdown_text = countdown_font.render(str(i), True, white)
            screen.blit(countdown_text, (
            screen_width // 2 - countdown_text.get_width() // 2, screen_height // 2 - countdown_text.get_height() // 2))
            pygame.display.flip()
            pygame.time.delay(1000)

        # Inicialização das configurações do jogo

    screen_width = 1435  # Largura da tela
    screen_height = 900  # Altura da tela
    screen = pygame.display.set_mode((screen_width, screen_height))
    pygame.display.set_caption("Jogo de Corrida")

    # Cores
    white = (255, 255, 255)
    black = (0, 0, 0)
    red = (255, 0, 0)

    # Carrega as imagens
    player_image = pygame.image.load("ythalo/TESTE1.png")
    player_width = 50
    player_height = 50
    player_image = pygame.transform.scale(player_image, (player_width, player_height))

    background_image = pygame.image.load("ythalo/espaco-sideral.png")
    background_image = pygame.transform.scale(background_image, (screen_width, screen_height))

    obstacle_image = pygame.image.load("ythalo/meteoro.png")
    obstacle_width = 70
    obstacle_height = 70
    obstacle_image = pygame.transform.scale(obstacle_image, (obstacle_width, obstacle_height))

    bullet_image = pygame.image.load("ythalo/bala.png")
    bullet_width = 30
    bullet_height = 30
    bullet_image = pygame.transform.scale(bullet_image, (bullet_width, bullet_height))

    # Definições do jogador
    player_x = (screen_width - player_width) // 2
    player_y = (screen_height - player_height) // 2
    player_speed = 10

    # Obstáculos
    num_obstacles = 13
    obstacles = []
    obstacle_speed = 10
    obstacle_acceleration = 0.25
    obstacle_health = [50, 25, 0]  # Adicionei diferentes níveis de saúde para os obstáculos

    for _ in range(num_obstacles):
        obstacle_x = random.randint(0, screen_width - obstacle_width)
        obstacle_y = random.randint(-screen_height, 0)
        # Use random.choice para definir a saúde do obstáculo aleatoriamente
        obstacles.append([obstacle_image, obstacle_x, obstacle_y, random.choice(obstacle_health)])

    # Barreira
    barrier_width = screen_width
    barrier_height = 10
    barrier_color = (0, 255, 0)
    barrier_y = screen_height - barrier_height

    # Velocidade inicial de queda dos obstáculos (reduzida)
    initial_fall_speed = 10
    fall_speed = initial_fall_speed

    # Movimento automático
    auto_move = None

    # Variáveis para controle de tempo
    clock = pygame.time.Clock()

    # Variáveis para controle de movimento vertical do jogador
    move_down = False
    move_up = False

    # Variáveis para controle de tiros do jogador
    bullets = []
    bullet_speed = 15
    bullet_damage = [15, 50, 25]

    # Variável para controle de game over
    game_over = False

    # Inicializa o tempo de jogo
    start_time = pygame.time.get_ticks()

    # Tela de contagem regressiva
    countdown_screen()

    # Game Loop
    while not game_over:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                game_over = True
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_a:
                    auto_move = "left"
                elif event.key == pygame.K_d:
                    auto_move = "right"
                elif event.key == pygame.K_SPACE:
                    fire_bullet(player_x + player_width // 2 - bullet_width // 2,
                                player_y - bullet_height)  # Posição inicial da bala ajustada para cima
                elif event.key == pygame.K_s:
                    move_down = True
                elif event.key == pygame.K_w:
                    move_up = True
            elif event.type == pygame.KEYUP:
                if event.key == pygame.K_s:
                    move_down = False
                elif event.key == pygame.K_w:
                    move_up = False

        keys = pygame.key.get_pressed()
        if keys[pygame.K_a]:
            auto_move = "left"
        elif keys[pygame.K_d]:
            auto_move = "right"

        # Atualiza a velocidade de queda dos obstáculos com base no tempo decorrido
        current_time = pygame.time.get_ticks()
        elapsed_time = current_time - start_time
        fall_speed = initial_fall_speed + elapsed_time * obstacle_acceleration / 1000.0

        # Movimento automático
        if auto_move == "left":
            player_x -= player_speed
        elif auto_move == "right":
            player_x += player_speed

        # Movimento vertical do jogador
        if move_down and not move_up:
            player_y += player_speed
        elif move_up and not move_down:
            player_y -= player_speed

        # Limite do jogador dentro da tela
        player_x = max(0, min(player_x, screen_width - player_width))
        player_y = max(0, min(player_y, screen_height - player_height))

        # Movimento dos obstáculos
        for obstacle in obstacles[:]:
            obstacle[2] += fall_speed
            if obstacle[2] > screen_height:
                obstacles.remove(obstacle)

                obstacle_x = random.randint(0, screen_width - obstacle_width)
                obstacle_y = random.randint(-screen_height, 0)
                obstacles.append([obstacle_image, obstacle_x, obstacle_y, random.choice(obstacle_health)])

        # Movimento das balas
        for bullet in bullets:
            bullet[2] -= bullet_speed
            if bullet[2] < 0:
                bullets.remove(bullet)

        # Verificação de colisão com os obstáculos
        for bullet in bullets[:]:
            for obstacle in obstacles[:]:
                if bullet[1] < obstacle[1] + obstacle_width and bullet[1] + bullet_width > obstacle[1] and bullet[2] < \
                        obstacle[2] + obstacle_height and bullet[2] + bullet_height > obstacle[2]:
                    # Reduza a saúde do obstáculo em vez de subtrair um valor fixo
                    obstacle[3] -= random.choice(bullet_damage)
                    if obstacle[3] <= 0:
                        obstacles.remove(obstacle)
                    bullets.remove(bullet)

        # Verificação de colisão com os obstáculos
        for obstacle in obstacles[:]:
            if player_x < obstacle[1] + obstacle_width and player_x + player_width > obstacle[1] and player_y < \
                    obstacle[2] + obstacle_height and player_y + player_height > obstacle[2]:
                game_over = True  # Encerra o jogo se houver colisão com um obstáculo

        # Preenche a tela com o fundo
        screen.blit(background_image, (0, 0))

        # Desenha a barreira
        pygame.draw.rect(screen, barrier_color, (0, barrier_y, screen_width, barrier_height))

        # Desenha o jogador, obstáculos e tiros
        screen.blit(player_image, (player_x, player_y))
        for obstacle in obstacles:
            screen.blit(obstacle[0], (obstacle[1], obstacle[2]))
        for bullet in bullets:
            screen.blit(bullet[0], (bullet[1], bullet[2]))

        # Atualiza o tempo de jogo
        current_time = pygame.time.get_ticks()
        elapsed_time = current_time - start_time

        # Atualiza a tela
        pygame.display.flip()

        # Limita a taxa de quadros por segundo
        clock.tick(60)

        restart_button_rect = pygame.Rect(500, 700, 100, 50)

    # Exibir "Fim de Jogo" após o fim do jogo
    while game_over:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()

            # Verifica se o botão de reiniciar o jogo foi clicado
            if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                if restart_button_rect.collidepoint(event.pos):
                    restart_game()

        screen.fill(black)
        font = pygame.font.Font(None, 72)
        game_over_text = font.render("Fim de Jogo", True, red)
        screen.blit(game_over_text,
                    (screen_width // 2 - game_over_text.get_width() // 2,
                     screen_height // 2 - game_over_text.get_height() // 2))

        # Exibe o tempo de jogo formatado em minutos e segundos na tela de fim de jogo
        game_time_seconds = int(elapsed_time / 1000)  # Converte para segundos
        game_time_minutes = game_time_seconds // 60  # Calcula os minutos
        time_text = font.render(f"Tempo de Jogo: {game_time_minutes:02}:{game_time_seconds % 60:02}", True, white)
        screen.blit(time_text, (screen_width // 2 - time_text.get_width() // 2, screen_height // 2 + 50))

        pygame.draw.rect(screen, red, restart_button_rect)

        pygame.display.flip()

    pygame.quit()
    sys.exit()

def janela3():
    tela_de_menu = pygame.display.set_mode((Largura, Altura))
    pygame.display.set_caption("janela menu")

    imagem = pygame.image.load("telas/tela3.png")
    imagem = pygame.transform.scale(imagem, (Largura, Altura))

    tela_de_menu.blit(imagem, (0, 0))

    botao_sair = pygame.image.load("invisible.png")
    botao_voltar = pygame.image.load("invisible.png")
    botao_verdadeiro = pygame.image.load("musica_play.png")
    botao_falso = pygame.image.load("musica_palse.png")
    botao_musica = botao_verdadeiro

    botao_voltar_pos = pygame.Rect(370, 90, 300, 120)
    botao_musica_pos = pygame.Rect(170, 220, 300, 110)
    botao_sair_pos = pygame.Rect(370, 400, 300, 120)

    botao_sair = pygame.transform.scale(botao_sair, (300, 120))
    botao_voltar = pygame.transform.scale(botao_voltar, (300, 120))
    botao_verdadeiro = pygame.transform.scale(botao_verdadeiro, (320, 170))
    botao_falso = pygame.transform.scale(botao_falso, (320, 170))
    botao_musica = pygame.transform.scale(botao_musica, (320, 170))

    botao_click_on = pygame.image.load("efeito_on.png")
    botao_click_off = pygame.image.load("efeito_off.png")

    botao_click_pos = pygame.Rect(560, 220, 300, 110)

    botao_click_on = pygame.transform.scale(botao_click_on, (320, 170))
    botao_click_off = pygame.transform.scale(botao_click_off, (320, 170))

    tela_de_menu.blit(botao_click_on, botao_click_pos)

    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif event.type == pygame.MOUSEBUTTONDOWN:
                if botao_voltar_pos.collidepoint(event.pos):
                    click.play()
                    janela1()
                elif botao_sair_pos.collidepoint(event.pos):
                    pygame.quit()
                    sys.exit()
                elif botao_musica_pos.collidepoint(event.pos):
                    if botao_musica == botao_verdadeiro:
                        botao_musica = botao_falso
                        pygame.mixer.music.pause()
                    else:
                        botao_musica = botao_verdadeiro
                        pygame.mixer.music.unpause()
                    click.play()
                    tela_de_menu.blit(imagem, (0, 0))
                    tela_de_menu.blit(botao_musica, botao_musica_pos)

                elif botao_click_pos.collidepoint(event.pos):
                    global som_de_click_ativo
                    if som_de_click_ativo:
                        som_de_click_ativo = False
                    else:
                        som_de_click_ativo = True

        tela_de_menu.blit(botao_musica, botao_musica_pos)
        tela_de_menu.blit(botao_voltar, botao_voltar_pos)
        tela_de_menu.blit(botao_sair, botao_sair_pos)

        if som_de_click_ativo:
            tela_de_menu.blit(botao_click_on, botao_click_pos)
        else:
            tela_de_menu.blit(botao_click_off, botao_click_pos)

        pygame.display.update()


def janela_de_creditos():
    janela_creditos = pygame.display.set_mode((Largura, Altura))
    pygame.display.set_caption("Janela de Créditos")

    imagem = pygame.image.load("telas/Tela de créditos.png")

    imagem = pygame.transform.scale(imagem, (Largura, Altura))

    janela_creditos.blit(imagem, (0, 0))

    botao_voltar = pygame.image.load("invisible.png")

    botao_voltar_pos = pygame.Rect(890, 420, 170, 150)

    botao_voltar = pygame.transform.scale(botao_voltar, (170, 150))

    janela_creditos.blit(botao_voltar, botao_voltar_pos)

    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif event.type == pygame.MOUSEBUTTONDOWN:
                if botao_voltar_pos.collidepoint(event.pos):
                    if som_de_click_ativo:
                        click.play()
                    janela1()

        pygame.display.update()


def erro():
    telaerro = pygame.display.set_mode((Largura, Altura))
    pygame.display.set_caption("Quiz Python")

    tela_errou = pygame.image.load("telas/telaerrou.png")
    tela_errou = pygame.transform.scale(tela_errou, (Largura, Altura))

    telaerro.blit(tela_errou, (0, 0))

    botao_voltar = pygame.image.load("invisible.png")
    botao_voltar_pos = pygame.Rect(10, 500, 490, 400)

    botao_voltar = pygame.transform.scale(botao_voltar, (220, 130))

    botao_recomecar = pygame.image.load("invisible.png")
    botao_recomecar_pos = pygame.Rect(850, 450, 240, 140)

    botao_recomecar = pygame.transform.scale(botao_recomecar, (240, 140))

    telaerro.blit(botao_voltar, botao_voltar_pos)
    telaerro.blit(botao_recomecar, botao_recomecar_pos)

    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif event.type == pygame.MOUSEBUTTONDOWN:
                if botao_voltar_pos.collidepoint(event.pos):
                    if som_de_click_ativo:
                        click.play()
                    janela3()

                elif botao_recomecar_pos.collidepoint(event.pos):
                    menu_do_quiz()

        pygame.display.update()


def final():
    janela = pygame.display.set_mode((Largura, Altura))
    pygame.display.set_caption("Quiz Python")

    imagem = pygame.image.load("telas/final.png")
    imagem = pygame.transform.scale(imagem, (Largura, Altura))

    janela.blit(imagem, (0, 0))

    BRANCO = (255, 255, 255)
    PRETO = (0, 0, 0)
    V = (0, 128, 0)
    P = (194, 204, 160)

    botao_img = pygame.image.load("invisible.png")
    botao_pos = pygame.Rect(900, 450, 490, 400)

    global ponto

    botao_img = pygame.transform.scale(botao_img, (220, 130))
    fonte = pygame.font.Font('arial.ttf', 200)
    superficie_do_numero = fonte.render(str(ponto), True, BRANCO)

    janela.blit(botao_img, botao_pos)
    janela.blit(superficie_do_numero, (400, 350))

    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif event.type == pygame.MOUSEBUTTONDOWN:
                if botao_pos.collidepoint(event.pos):
                    menu_do_quiz()
                # Play the sound when the button is clicked

        pygame.display.update()

def final1():
    janela = pygame.display.set_mode((Largura, Altura))
    pygame.display.set_caption("Quiz Python")

    imagem = pygame.image.load("telas/final.png")
    imagem = pygame.transform.scale(imagem, (Largura, Altura))

    janela.blit(imagem, (0, 0))

    BRANCO = (255, 255, 255)
    PRETO = (0, 0, 0)
    V = (0, 128, 0)
    P = (194, 204, 160)

    botao_img = pygame.image.load("invisible.png")
    botao_pos = pygame.Rect(900, 450, 490, 400)

    global ponto1

    botao_img = pygame.transform.scale(botao_img, (220, 130))
    fonte = pygame.font.Font('arial.ttf', 200)
    superficie_do_numero = fonte.render(str(ponto1), True, BRANCO)

    superficie_do_numero1 = fonte.render(str(ponto1), True, BRANCO)

    janela.blit(botao_img, botao_pos)
    janela.blit(superficie_do_numero1, (400, 350))


    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif event.type == pygame.MOUSEBUTTONDOWN:
                if botao_pos.collidepoint(event.pos):
                    menu_do_quiz()
                # Play the sound when the button is clicked

        pygame.display.update()

def final2():
    janela = pygame.display.set_mode((Largura, Altura))
    pygame.display.set_caption("Quiz Python")

    imagem = pygame.image.load("telas/final.png")
    imagem = pygame.transform.scale(imagem, (Largura, Altura))

    janela.blit(imagem, (0, 0))

    BRANCO = (255, 255, 255)
    PRETO = (0, 0, 0)
    V = (0, 128, 0)
    P = (194, 204, 160)

    botao_img = pygame.image.load("invisible.png")
    botao_pos = pygame.Rect(900, 450, 490, 400)

    global ponto2

    botao_img = pygame.transform.scale(botao_img, (220, 130))
    fonte = pygame.font.Font('arial.ttf', 200)

    superficie_do_numero2 = fonte.render(str(ponto2), True, BRANCO)

    janela.blit(botao_img, botao_pos)
    janela.blit(superficie_do_numero2, (400, 350))

    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif event.type == pygame.MOUSEBUTTONDOWN:
                if botao_pos.collidepoint(event.pos):
                    menu_do_quiz()
                # Play the sound when the button is clicked

        pygame.display.update()

def fase01():
    telafase_1 = pygame.display.set_mode((Largura, Altura))
    pygame.display.set_caption("fase 1")

    teladefase_1 = pygame.image.load("perguntas/fase1.png")
    teladefase_1 = pygame.transform.scale(teladefase_1, (Largura, Altura))

    telafase_1.blit(teladefase_1, (0, 0))
    global ponto1
    ponto1 = 0
    botao_voltar = pygame.image.load("invisible.png")
    botao_proximo = pygame.image.load("invisible.png")

    botao_voltar_pos = pygame.Rect(22, 400, 490, 400)
    botao_proximo_pos = pygame.Rect(850, 420, 240, 140)

    botao_voltar = pygame.transform.scale(botao_voltar, (220, 130))
    botao_proximo = pygame.transform.scale(botao_proximo, (250, 142))

    telafase_1.blit(botao_voltar, botao_voltar_pos)
    telafase_1.blit(botao_proximo, botao_proximo_pos)

    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif event.type == pygame.MOUSEBUTTONDOWN:
                if botao_voltar_pos.collidepoint(event.pos):
                    if som_de_click_ativo:
                        click.play()
                    janela1()

                elif event.type == pygame.MOUSEBUTTONDOWN:
                    if botao_proximo_pos.collidepoint(event.pos):
                        if som_de_click_ativo:
                            click.play()
                        questao1()

        pygame.display.update()


def questao1():
    teladequestao_1 = pygame.display.set_mode((Largura, Altura))
    pygame.display.set_caption("questão 1")

    imagem = pygame.image.load("perguntas/1.png")
    imagem = pygame.transform.scale(imagem, (Largura, Altura))

    teladequestao_1.blit(imagem, (0, 0))

    global ponto
    ponto = 0

    botaoA_img = pygame.image.load("invisible.png")
    botaoB_img = pygame.image.load("invisible.png")
    botaoC_img = pygame.image.load("invisible.png")
    botaoD_img = pygame.image.load("invisible.png")

    botaoA_pos = pygame.Rect(100, 280, 400, 100)
    botaoB_pos = pygame.Rect(600, 280, 400, 100)
    botaoC_pos = pygame.Rect(120, 390, 400, 100)
    botaoD_pos = pygame.Rect(620, 390, 400, 100)

    botaoA_img = pygame.transform.scale(botaoA_img, (400, 100))
    botaoB_img = pygame.transform.scale(botaoB_img, (400, 100))
    botaoC_img = pygame.transform.scale(botaoC_img, (400, 100))
    botaoD_img = pygame.transform.scale(botaoD_img, (400, 100))

    teladequestao_1.blit(botaoA_img, botaoA_pos)
    teladequestao_1.blit(botaoB_img, botaoB_pos)
    teladequestao_1.blit(botaoC_img, botaoC_pos)
    teladequestao_1.blit(botaoD_img, botaoD_pos)

    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif event.type == pygame.MOUSEBUTTONDOWN:

                if botaoA_pos.collidepoint(event.pos):
                    erro()

                elif botaoB_pos.collidepoint(event.pos):
                    erro()

                elif botaoC_pos.collidepoint(event.pos):
                    erro()

                elif botaoD_pos.collidepoint(event.pos):
                    c.play()
                    ponto += 10
                    questao2()
                    # correto

        pygame.display.update()


def questao2():
    teladequestao_2 = pygame.display.set_mode((Largura, Altura))
    pygame.display.set_caption("questão 2")

    imagem = pygame.image.load("perguntas/2.png")
    imagem = pygame.transform.scale(imagem, (Largura, Altura))

    teladequestao_2.blit(imagem, (0, 0))

    global ponto

    botaoA_img = pygame.image.load("invisible.png")
    botaoB_img = pygame.image.load("invisible.png")
    botaoC_img = pygame.image.load("invisible.png")
    botaoD_img = pygame.image.load("invisible.png")

    botaoA_pos = pygame.Rect(100, 280, 400, 100)
    botaoB_pos = pygame.Rect(600, 280, 400, 100)
    botaoC_pos = pygame.Rect(120, 390, 400, 100)
    botaoD_pos = pygame.Rect(620, 390, 400, 100)

    botaoA_img = pygame.transform.scale(botaoA_img, (400, 100))
    botaoB_img = pygame.transform.scale(botaoB_img, (400, 100))
    botaoC_img = pygame.transform.scale(botaoC_img, (400, 100))
    botaoD_img = pygame.transform.scale(botaoD_img, (400, 100))

    teladequestao_2.blit(botaoA_img, botaoA_pos)
    teladequestao_2.blit(botaoB_img, botaoB_pos)
    teladequestao_2.blit(botaoC_img, botaoC_pos)
    teladequestao_2.blit(botaoD_img, botaoD_pos)

    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif event.type == pygame.MOUSEBUTTONDOWN:

                if botaoA_pos.collidepoint(event.pos):
                    c.play()
                    ponto += 10
                    questao3()
                    # correto

                elif botaoB_pos.collidepoint(event.pos):
                    erro()

                elif botaoC_pos.collidepoint(event.pos):
                    erro()

                elif botaoD_pos.collidepoint(event.pos):
                    erro()

        pygame.display.update()


def questao3():
    teladequestao_3 = pygame.display.set_mode((Largura, Altura))
    pygame.display.set_caption("questão 2")

    imagem = pygame.image.load("perguntas/3.png")
    imagem = pygame.transform.scale(imagem, (Largura, Altura))

    teladequestao_3.blit(imagem, (0, 0))

    global ponto

    botaoA_img = pygame.image.load("invisible.png")
    botaoB_img = pygame.image.load("invisible.png")
    botaoC_img = pygame.image.load("invisible.png")
    botaoD_img = pygame.image.load("invisible.png")

    botaoA_pos = pygame.Rect(100, 280, 400, 100)
    botaoB_pos = pygame.Rect(600, 280, 400, 100)
    botaoC_pos = pygame.Rect(120, 390, 400, 100)
    botaoD_pos = pygame.Rect(620, 390, 400, 100)

    botaoA_img = pygame.transform.scale(botaoA_img, (400, 100))
    botaoB_img = pygame.transform.scale(botaoB_img, (400, 100))
    botaoC_img = pygame.transform.scale(botaoC_img, (400, 100))
    botaoD_img = pygame.transform.scale(botaoD_img, (400, 100))

    teladequestao_3.blit(botaoA_img, botaoA_pos)
    teladequestao_3.blit(botaoB_img, botaoB_pos)
    teladequestao_3.blit(botaoC_img, botaoC_pos)
    teladequestao_3.blit(botaoD_img, botaoD_pos)

    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif event.type == pygame.MOUSEBUTTONDOWN:

                if botaoA_pos.collidepoint(event.pos):
                    erro()

                elif botaoB_pos.collidepoint(event.pos):
                    erro()

                elif botaoC_pos.collidepoint(event.pos):
                    c.play()
                    ponto += 10
                    questao4()

                    # correto

                elif botaoD_pos.collidepoint(event.pos):
                    erro()

        pygame.display.update()


def questao4():
    teladequestao_4 = pygame.display.set_mode((Largura, Altura))
    pygame.display.set_caption("questão 4")

    imagem = pygame.image.load("perguntas/4.png")
    imagem = pygame.transform.scale(imagem, (Largura, Altura))

    teladequestao_4.blit(imagem, (0, 0))

    global ponto

    botaoA_img = pygame.image.load("invisible.png")
    botaoB_img = pygame.image.load("invisible.png")
    botaoC_img = pygame.image.load("invisible.png")
    botaoD_img = pygame.image.load("invisible.png")

    botaoA_pos = pygame.Rect(100, 280, 400, 100)
    botaoB_pos = pygame.Rect(600, 280, 400, 100)
    botaoC_pos = pygame.Rect(120, 390, 400, 100)
    botaoD_pos = pygame.Rect(620, 390, 400, 100)

    botaoA_img = pygame.transform.scale(botaoA_img, (400, 100))
    botaoB_img = pygame.transform.scale(botaoB_img, (400, 100))
    botaoC_img = pygame.transform.scale(botaoC_img, (400, 100))
    botaoD_img = pygame.transform.scale(botaoD_img, (400, 100))

    teladequestao_4.blit(botaoA_img, botaoA_pos)
    teladequestao_4.blit(botaoB_img, botaoB_pos)
    teladequestao_4.blit(botaoC_img, botaoC_pos)
    teladequestao_4.blit(botaoD_img, botaoD_pos)

    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif event.type == pygame.MOUSEBUTTONDOWN:

                if botaoA_pos.collidepoint(event.pos):
                    erro()

                elif botaoB_pos.collidepoint(event.pos):
                    erro()

                elif botaoC_pos.collidepoint(event.pos):
                    c.play()
                    ponto += 10
                    questao5()
                    # correto

                elif botaoD_pos.collidepoint(event.pos):
                    erro()

        pygame.display.update()


def questao5():
    teladequestao_5 = pygame.display.set_mode((Largura, Altura))
    pygame.display.set_caption("questão 5")

    imagem = pygame.image.load("perguntas/5.png")
    imagem = pygame.transform.scale(imagem, (Largura, Altura))

    teladequestao_5.blit(imagem, (0, 0))

    global ponto

    botaoA_img = pygame.image.load("invisible.png")
    botaoB_img = pygame.image.load("invisible.png")
    botaoC_img = pygame.image.load("invisible.png")
    botaoD_img = pygame.image.load("invisible.png")

    botaoA_pos = pygame.Rect(100, 280, 400, 100)
    botaoB_pos = pygame.Rect(600, 280, 400, 100)
    botaoC_pos = pygame.Rect(120, 390, 400, 100)
    botaoD_pos = pygame.Rect(620, 390, 400, 100)

    botaoA_img = pygame.transform.scale(botaoA_img, (400, 100))
    botaoB_img = pygame.transform.scale(botaoB_img, (400, 100))
    botaoC_img = pygame.transform.scale(botaoC_img, (400, 100))
    botaoD_img = pygame.transform.scale(botaoD_img, (400, 100))

    teladequestao_5.blit(botaoA_img, botaoA_pos)
    teladequestao_5.blit(botaoB_img, botaoB_pos)
    teladequestao_5.blit(botaoC_img, botaoC_pos)
    teladequestao_5.blit(botaoD_img, botaoD_pos)

    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif event.type == pygame.MOUSEBUTTONDOWN:

                if botaoA_pos.collidepoint(event.pos):
                    erro()

                elif botaoB_pos.collidepoint(event.pos):
                    erro()

                elif botaoC_pos.collidepoint(event.pos):
                    c.play()
                    ponto += 10
                    questao6()
                    # correto

                elif botaoD_pos.collidepoint(event.pos):
                    erro()

        pygame.display.update()


def questao6():
    teladequestao_6 = pygame.display.set_mode((Largura, Altura))
    pygame.display.set_caption("questão 6")

    imagem = pygame.image.load("perguntas/6.png")
    imagem = pygame.transform.scale(imagem, (Largura, Altura))

    teladequestao_6.blit(imagem, (0, 0))

    global ponto

    botaoA_img = pygame.image.load("invisible.png")
    botaoB_img = pygame.image.load("invisible.png")
    botaoC_img = pygame.image.load("invisible.png")
    botaoD_img = pygame.image.load("invisible.png")

    botaoA_pos = pygame.Rect(100, 280, 400, 100)
    botaoB_pos = pygame.Rect(600, 280, 400, 100)
    botaoC_pos = pygame.Rect(120, 390, 400, 100)
    botaoD_pos = pygame.Rect(620, 390, 400, 100)

    botaoA_img = pygame.transform.scale(botaoA_img, (400, 100))
    botaoB_img = pygame.transform.scale(botaoB_img, (400, 100))
    botaoC_img = pygame.transform.scale(botaoC_img, (400, 100))
    botaoD_img = pygame.transform.scale(botaoD_img, (400, 100))

    teladequestao_6.blit(botaoA_img, botaoA_pos)
    teladequestao_6.blit(botaoB_img, botaoB_pos)
    teladequestao_6.blit(botaoC_img, botaoC_pos)
    teladequestao_6.blit(botaoD_img, botaoD_pos)
    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif event.type == pygame.MOUSEBUTTONDOWN:

                if botaoA_pos.collidepoint(event.pos):
                    c.play()
                    ponto += 10
                    final()
                    # correto

                elif botaoB_pos.collidepoint(event.pos):
                    erro()

                elif botaoC_pos.collidepoint(event.pos):
                    erro()

                elif botaoD_pos.collidepoint(event.pos):
                    erro()

        pygame.display.update()


def fase02():
    telafase_2 = pygame.display.set_mode((Largura, Altura))
    pygame.display.set_caption("fase 2")

    teladefase_2 = pygame.image.load("perguntas/fase2.png")
    teladefase_2 = pygame.transform.scale(teladefase_2, (Largura, Altura))

    telafase_2.blit(teladefase_2, (0, 0))
    global ponto
    ponto = 0
    botao_voltar = pygame.image.load("invisible.png")
    botao_proximo = pygame.image.load("invisible.png")

    botao_voltar_pos = pygame.Rect(22, 400, 490, 400)
    botao_proximo_pos = pygame.Rect(850, 420, 240, 140)

    botao_voltar = pygame.transform.scale(botao_voltar, (220, 130))
    botao_proximo = pygame.transform.scale(botao_proximo, (250, 142))

    telafase_2.blit(botao_voltar, botao_voltar_pos)
    telafase_2.blit(botao_proximo, botao_proximo_pos)

    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif event.type == pygame.MOUSEBUTTONDOWN:
                if botao_voltar_pos.collidepoint(event.pos):
                    if som_de_click_ativo:
                        click.play()
                    janela1()

                elif event.type == pygame.MOUSEBUTTONDOWN:
                    if botao_proximo_pos.collidepoint(event.pos):
                        if som_de_click_ativo:
                            click.play()
                        questao7()

        pygame.display.update()


def questao7():
    teladequestao_7 = pygame.display.set_mode((Largura, Altura))
    pygame.display.set_caption("questão 7")

    imagem = pygame.image.load("perguntas/7.png")
    imagem = pygame.transform.scale(imagem, (Largura, Altura))

    teladequestao_7.blit(imagem, (0, 0))
    global ponto1
    ponto1 = 0
    botaoA_img = pygame.image.load("invisible.png")
    botaoB_img = pygame.image.load("invisible.png")
    botaoC_img = pygame.image.load("invisible.png")
    botaoD_img = pygame.image.load("invisible.png")

    botaoA_pos = pygame.Rect(100, 280, 400, 100)
    botaoB_pos = pygame.Rect(600, 280, 400, 100)
    botaoC_pos = pygame.Rect(120, 390, 400, 100)
    botaoD_pos = pygame.Rect(620, 390, 400, 100)

    botaoA_img = pygame.transform.scale(botaoA_img, (400, 100))
    botaoB_img = pygame.transform.scale(botaoB_img, (400, 100))
    botaoC_img = pygame.transform.scale(botaoC_img, (400, 100))
    botaoD_img = pygame.transform.scale(botaoD_img, (400, 100))

    teladequestao_7.blit(botaoA_img, botaoA_pos)
    teladequestao_7.blit(botaoB_img, botaoB_pos)
    teladequestao_7.blit(botaoC_img, botaoC_pos)
    teladequestao_7.blit(botaoD_img, botaoD_pos)

    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif event.type == pygame.MOUSEBUTTONDOWN:

                if botaoA_pos.collidepoint(event.pos):
                    erro()

                elif botaoB_pos.collidepoint(event.pos):
                    erro()

                elif botaoC_pos.collidepoint(event.pos):
                    c.play()
                    ponto1 += 10
                    questao8()
                    # correto

                elif botaoD_pos.collidepoint(event.pos):
                    erro()

        pygame.display.update()


def questao8():
    teladequestao_8 = pygame.display.set_mode((Largura, Altura))
    pygame.display.set_caption("questão 8")

    imagem = pygame.image.load("perguntas/8.png")
    imagem = pygame.transform.scale(imagem, (Largura, Altura))

    teladequestao_8.blit(imagem, (0, 0))

    botaoA_img = pygame.image.load("invisible.png")
    botaoB_img = pygame.image.load("invisible.png")
    botaoC_img = pygame.image.load("invisible.png")
    botaoD_img = pygame.image.load("invisible.png")

    botaoA_pos = pygame.Rect(100, 280, 400, 100)
    botaoB_pos = pygame.Rect(600, 280, 400, 100)
    botaoC_pos = pygame.Rect(120, 390, 400, 100)
    botaoD_pos = pygame.Rect(620, 390, 400, 100)

    botaoA_img = pygame.transform.scale(botaoA_img, (400, 100))
    botaoB_img = pygame.transform.scale(botaoB_img, (400, 100))
    botaoC_img = pygame.transform.scale(botaoC_img, (400, 100))
    botaoD_img = pygame.transform.scale(botaoD_img, (400, 100))

    teladequestao_8.blit(botaoA_img, botaoA_pos)
    teladequestao_8.blit(botaoB_img, botaoB_pos)
    teladequestao_8.blit(botaoC_img, botaoC_pos)
    teladequestao_8.blit(botaoD_img, botaoD_pos)

    global ponto1

    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif event.type == pygame.MOUSEBUTTONDOWN:

                if botaoA_pos.collidepoint(event.pos):
                    erro()

                elif botaoB_pos.collidepoint(event.pos):
                    erro()

                elif botaoC_pos.collidepoint(event.pos):
                    erro()

                elif botaoD_pos.collidepoint(event.pos):
                    c.play()
                    ponto1 += 10
                    questao9()
                    # correto

        pygame.display.update()


def questao9():
    teladequestao_9 = pygame.display.set_mode((Largura, Altura))
    pygame.display.set_caption("questão 9")

    imagem = pygame.image.load("perguntas/9.png")
    imagem = pygame.transform.scale(imagem, (Largura, Altura))

    teladequestao_9.blit(imagem, (0, 0))

    botaoA_img = pygame.image.load("invisible.png")
    botaoB_img = pygame.image.load("invisible.png")
    botaoC_img = pygame.image.load("invisible.png")
    botaoD_img = pygame.image.load("invisible.png")

    botaoA_pos = pygame.Rect(100, 280, 400, 100)
    botaoB_pos = pygame.Rect(600, 280, 400, 100)
    botaoC_pos = pygame.Rect(120, 390, 400, 100)
    botaoD_pos = pygame.Rect(620, 390, 400, 100)

    botaoA_img = pygame.transform.scale(botaoA_img, (400, 100))
    botaoB_img = pygame.transform.scale(botaoB_img, (400, 100))
    botaoC_img = pygame.transform.scale(botaoC_img, (400, 100))
    botaoD_img = pygame.transform.scale(botaoD_img, (400, 100))

    teladequestao_9.blit(botaoA_img, botaoA_pos)
    teladequestao_9.blit(botaoB_img, botaoB_pos)
    teladequestao_9.blit(botaoC_img, botaoC_pos)
    teladequestao_9.blit(botaoD_img, botaoD_pos)

    global ponto1

    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif event.type == pygame.MOUSEBUTTONDOWN:

                if botaoA_pos.collidepoint(event.pos):
                    erro()

                elif botaoB_pos.collidepoint(event.pos):
                    erro()

                elif botaoC_pos.collidepoint(event.pos):
                    erro()

                elif botaoD_pos.collidepoint(event.pos):
                    c.play()
                    ponto1 += 10
                    questao10()
                    # correto


        pygame.display.update()


def questao10():
    teladequestao_10 = pygame.display.set_mode((Largura, Altura))
    pygame.display.set_caption("questão 10")

    imagem = pygame.image.load("perguntas/10.png")
    imagem = pygame.transform.scale(imagem, (Largura, Altura))

    teladequestao_10.blit(imagem, (0, 0))

    botaoA_img = pygame.image.load("invisible.png")
    botaoB_img = pygame.image.load("invisible.png")
    botaoC_img = pygame.image.load("invisible.png")
    botaoD_img = pygame.image.load("invisible.png")

    botaoA_pos = pygame.Rect(100, 280, 400, 100)
    botaoB_pos = pygame.Rect(600, 280, 400, 100)
    botaoC_pos = pygame.Rect(120, 390, 400, 100)
    botaoD_pos = pygame.Rect(620, 390, 400, 100)

    botaoA_img = pygame.transform.scale(botaoA_img, (400, 100))
    botaoB_img = pygame.transform.scale(botaoB_img, (400, 100))
    botaoC_img = pygame.transform.scale(botaoC_img, (400, 100))
    botaoD_img = pygame.transform.scale(botaoD_img, (400, 100))

    teladequestao_10.blit(botaoA_img, botaoA_pos)
    teladequestao_10.blit(botaoB_img, botaoB_pos)
    teladequestao_10.blit(botaoC_img, botaoC_pos)
    teladequestao_10.blit(botaoD_img, botaoD_pos)

    global ponto1

    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif event.type == pygame.MOUSEBUTTONDOWN:

                if botaoA_pos.collidepoint(event.pos):
                    erro()

                elif botaoB_pos.collidepoint(event.pos):
                    erro()

                elif botaoC_pos.collidepoint(event.pos):
                    c.play()
                    ponto1 += 10
                    questao11()
                    # correto

                elif botaoD_pos.collidepoint(event.pos):
                    erro()

        pygame.display.update()


def questao11():
    teladequestao_11 = pygame.display.set_mode((Largura, Altura))
    pygame.display.set_caption("questão 11")

    imagem = pygame.image.load("perguntas/11.png")
    imagem = pygame.transform.scale(imagem, (Largura, Altura))

    teladequestao_11.blit(imagem, (0, 0))

    botaoA_img = pygame.image.load("invisible.png")
    botaoB_img = pygame.image.load("invisible.png")
    botaoC_img = pygame.image.load("invisible.png")
    botaoD_img = pygame.image.load("invisible.png")

    botaoA_pos = pygame.Rect(100, 280, 400, 100)
    botaoB_pos = pygame.Rect(600, 280, 400, 100)
    botaoC_pos = pygame.Rect(120, 390, 400, 100)
    botaoD_pos = pygame.Rect(620, 390, 400, 100)

    botaoA_img = pygame.transform.scale(botaoA_img, (400, 100))
    botaoB_img = pygame.transform.scale(botaoB_img, (400, 100))
    botaoC_img = pygame.transform.scale(botaoC_img, (400, 100))
    botaoD_img = pygame.transform.scale(botaoD_img, (400, 100))

    teladequestao_11.blit(botaoA_img, botaoA_pos)
    teladequestao_11.blit(botaoB_img, botaoB_pos)
    teladequestao_11.blit(botaoC_img, botaoC_pos)
    teladequestao_11.blit(botaoD_img, botaoD_pos)

    global ponto1

    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif event.type == pygame.MOUSEBUTTONDOWN:

                if botaoA_pos.collidepoint(event.pos):
                    erro()

                elif botaoB_pos.collidepoint(event.pos):
                    erro()

                elif botaoC_pos.collidepoint(event.pos):
                    c.play()
                    ponto1 += 10
                    questao12()
                    # correto

                elif botaoD_pos.collidepoint(event.pos):
                    erro()

        pygame.display.update()


def questao12():
    teladequestao_12 = pygame.display.set_mode((Largura, Altura))
    pygame.display.set_caption("questão 12")

    imagem = pygame.image.load("perguntas/12.png")
    imagem = pygame.transform.scale(imagem, (Largura, Altura))

    teladequestao_12.blit(imagem, (0, 0))

    botaoA_img = pygame.image.load("invisible.png")
    botaoB_img = pygame.image.load("invisible.png")
    botaoC_img = pygame.image.load("invisible.png")
    botaoD_img = pygame.image.load("invisible.png")

    botaoA_pos = pygame.Rect(100, 280, 400, 100)
    botaoB_pos = pygame.Rect(600, 280, 400, 100)
    botaoC_pos = pygame.Rect(120, 390, 400, 100)
    botaoD_pos = pygame.Rect(620, 390, 400, 100)

    botaoA_img = pygame.transform.scale(botaoA_img, (400, 100))
    botaoB_img = pygame.transform.scale(botaoB_img, (400, 100))
    botaoC_img = pygame.transform.scale(botaoC_img, (400, 100))
    botaoD_img = pygame.transform.scale(botaoD_img, (400, 100))

    teladequestao_12.blit(botaoA_img, botaoA_pos)
    teladequestao_12.blit(botaoB_img, botaoB_pos)
    teladequestao_12.blit(botaoC_img, botaoC_pos)
    teladequestao_12.blit(botaoD_img, botaoD_pos)

    global ponto1
    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif event.type == pygame.MOUSEBUTTONDOWN:

                if botaoA_pos.collidepoint(event.pos):
                    erro()

                elif botaoB_pos.collidepoint(event.pos):
                    c.play()
                    ponto1 += 10
                    final1()
                    # correto

                elif botaoC_pos.collidepoint(event.pos):
                    erro()

                elif botaoD_pos.collidepoint(event.pos):
                    erro()

        pygame.display.update()


def fase03():
    telafase_3 = pygame.display.set_mode((Largura, Altura))
    pygame.display.set_caption("fase 3")

    teladefase_3 = pygame.image.load("perguntas/fase3.png")
    teladefase_3 = pygame.transform.scale(teladefase_3, (Largura, Altura))

    telafase_3.blit(teladefase_3, (0, 0))
    global ponto3 
    ponto3 = 0
    botao_voltar = pygame.image.load("invisible.png")
    botao_proximo = pygame.image.load("invisible.png")

    botao_voltar_pos = pygame.Rect(22, 400, 490, 400)
    botao_proximo_pos = pygame.Rect(850, 420, 240, 140)

    botao_voltar = pygame.transform.scale(botao_voltar, (220, 130))
    botao_proximo = pygame.transform.scale(botao_proximo, (250, 142))

    telafase_3.blit(botao_voltar, botao_voltar_pos)
    telafase_3.blit(botao_proximo, botao_proximo_pos)

    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif event.type == pygame.MOUSEBUTTONDOWN:
                if botao_voltar_pos.collidepoint(event.pos):
                    if som_de_click_ativo:
                        click.play()
                    menu_do_quiz()

                elif event.type == pygame.MOUSEBUTTONDOWN:
                    if botao_proximo_pos.collidepoint(event.pos):
                        if som_de_click_ativo:
                            click.play()
                        questao13()

        pygame.display.update()


def questao13():
    teladequestao_13 = pygame.display.set_mode((Largura, Altura))
    pygame.display.set_caption("questão 13")

    imagem = pygame.image.load("perguntas/13.png")
    imagem = pygame.transform.scale(imagem, (Largura, Altura))

    teladequestao_13.blit(imagem, (0, 0))

    global ponto2
    ponto2 = 0

    botaoA_img = pygame.image.load("invisible.png")
    botaoB_img = pygame.image.load("invisible.png")
    botaoC_img = pygame.image.load("invisible.png")
    botaoD_img = pygame.image.load("invisible.png")

    botaoA_pos = pygame.Rect(100, 280, 400, 100)
    botaoB_pos = pygame.Rect(600, 280, 400, 100)
    botaoC_pos = pygame.Rect(120, 390, 400, 100)
    botaoD_pos = pygame.Rect(620, 390, 400, 100)

    botaoA_img = pygame.transform.scale(botaoA_img, (400, 100))
    botaoB_img = pygame.transform.scale(botaoB_img, (400, 100))
    botaoC_img = pygame.transform.scale(botaoC_img, (400, 100))
    botaoD_img = pygame.transform.scale(botaoD_img, (400, 100))

    teladequestao_13.blit(botaoA_img, botaoA_pos)
    teladequestao_13.blit(botaoB_img, botaoB_pos)
    teladequestao_13.blit(botaoC_img, botaoC_pos)
    teladequestao_13.blit(botaoD_img, botaoD_pos)


    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif event.type == pygame.MOUSEBUTTONDOWN:

                if botaoA_pos.collidepoint(event.pos):
                    erro()

                elif botaoB_pos.collidepoint(event.pos):
                    erro()
                    # correto

                elif botaoC_pos.collidepoint(event.pos):
                    c.play()
                    ponto2 += 10
                    questao14()

                elif botaoD_pos.collidepoint(event.pos):
                    erro()

        pygame.display.update()


def questao14():
    teladequestao_14 = pygame.display.set_mode((Largura, Altura))
    pygame.display.set_caption("questão 14")

    imagem = pygame.image.load("perguntas/14.png")
    imagem = pygame.transform.scale(imagem, (Largura, Altura))

    teladequestao_14.blit(imagem, (0, 0))

    botaoA_img = pygame.image.load("invisible.png")
    botaoB_img = pygame.image.load("invisible.png")
    botaoC_img = pygame.image.load("invisible.png")
    botaoD_img = pygame.image.load("invisible.png")

    botaoA_pos = pygame.Rect(100, 280, 400, 100)
    botaoB_pos = pygame.Rect(600, 280, 400, 100)
    botaoC_pos = pygame.Rect(120, 390, 400, 100)
    botaoD_pos = pygame.Rect(620, 390, 400, 100)

    botaoA_img = pygame.transform.scale(botaoA_img, (400, 100))
    botaoB_img = pygame.transform.scale(botaoB_img, (400, 100))
    botaoC_img = pygame.transform.scale(botaoC_img, (400, 100))
    botaoD_img = pygame.transform.scale(botaoD_img, (400, 100))

    teladequestao_14.blit(botaoA_img, botaoA_pos)
    teladequestao_14.blit(botaoB_img, botaoB_pos)
    teladequestao_14.blit(botaoC_img, botaoC_pos)
    teladequestao_14.blit(botaoD_img, botaoD_pos)

    global ponto2
    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif event.type == pygame.MOUSEBUTTONDOWN:

                if botaoA_pos.collidepoint(event.pos):
                    erro()

                elif botaoB_pos.collidepoint(event.pos):
                    erro()
                    # correto

                elif botaoC_pos.collidepoint(event.pos):
                    c.play()
                    ponto2 += 10
                    questao15()

                elif botaoD_pos.collidepoint(event.pos):
                    erro()

        pygame.display.update()

def questao15():
    teladequestao_15 = pygame.display.set_mode((Largura, Altura))
    pygame.display.set_caption("questão 15")

    imagem = pygame.image.load("perguntas/15.png")
    imagem = pygame.transform.scale(imagem, (Largura, Altura))

    teladequestao_15.blit(imagem, (0, 0))

    botaoA_img = pygame.image.load("invisible.png")
    botaoB_img = pygame.image.load("invisible.png")
    botaoC_img = pygame.image.load("invisible.png")
    botaoD_img = pygame.image.load("invisible.png")

    botaoA_pos = pygame.Rect(100, 280, 400, 100)
    botaoB_pos = pygame.Rect(600, 280, 400, 100)
    botaoC_pos = pygame.Rect(120, 390, 400, 100)
    botaoD_pos = pygame.Rect(620, 390, 400, 100)

    botaoA_img = pygame.transform.scale(botaoA_img, (400, 100))
    botaoB_img = pygame.transform.scale(botaoB_img, (400, 100))
    botaoC_img = pygame.transform.scale(botaoC_img, (400, 100))
    botaoD_img = pygame.transform.scale(botaoD_img, (400, 100))

    teladequestao_15.blit(botaoA_img, botaoA_pos)
    teladequestao_15.blit(botaoB_img, botaoB_pos)
    teladequestao_15.blit(botaoC_img, botaoC_pos)
    teladequestao_15.blit(botaoD_img, botaoD_pos)

    global ponto2
    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif event.type == pygame.MOUSEBUTTONDOWN:

                if botaoA_pos.collidepoint(event.pos):
                    erro()

                elif botaoB_pos.collidepoint(event.pos):
                    c.play()
                    ponto2 += 10
                    questao16()
                    # correto

                elif botaoC_pos.collidepoint(event.pos):
                    erro()

                elif botaoD_pos.collidepoint(event.pos):
                    erro()

        pygame.display.update()

def questao16():
    teladequestao_16 = pygame.display.set_mode((Largura, Altura))
    pygame.display.set_caption("questão 16")

    imagem = pygame.image.load("perguntas/16.png")
    imagem = pygame.transform.scale(imagem, (Largura, Altura))

    teladequestao_16.blit(imagem, (0, 0))

    botaoA_img = pygame.image.load("invisible.png")
    botaoB_img = pygame.image.load("invisible.png")
    botaoC_img = pygame.image.load("invisible.png")
    botaoD_img = pygame.image.load("invisible.png")

    botaoA_pos = pygame.Rect(100, 280, 400, 100)
    botaoB_pos = pygame.Rect(600, 280, 400, 100)
    botaoC_pos = pygame.Rect(120, 390, 400, 100)
    botaoD_pos = pygame.Rect(620, 390, 400, 100)

    botaoA_img = pygame.transform.scale(botaoA_img, (400, 100))
    botaoB_img = pygame.transform.scale(botaoB_img, (400, 100))
    botaoC_img = pygame.transform.scale(botaoC_img, (400, 100))
    botaoD_img = pygame.transform.scale(botaoD_img, (400, 100))

    teladequestao_16.blit(botaoA_img, botaoA_pos)
    teladequestao_16.blit(botaoB_img, botaoB_pos)
    teladequestao_16.blit(botaoC_img, botaoC_pos)
    teladequestao_16.blit(botaoD_img, botaoD_pos)

    global ponto2
    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif event.type == pygame.MOUSEBUTTONDOWN:

                if botaoA_pos.collidepoint(event.pos):
                    erro()

                elif botaoB_pos.collidepoint(event.pos):
                    c.play()
                    ponto2 += 10
                    questao17()
                    # correto

                elif botaoC_pos.collidepoint(event.pos):
                    erro()

                elif botaoD_pos.collidepoint(event.pos):
                    erro()

        pygame.display.update()


def questao17():
    teladequestao_17 = pygame.display.set_mode((Largura, Altura))
    pygame.display.set_caption("questão 17")

    imagem = pygame.image.load("perguntas/17.png")
    imagem = pygame.transform.scale(imagem, (Largura, Altura))

    teladequestao_17.blit(imagem, (0, 0))

    botaoA_img = pygame.image.load("invisible.png")
    botaoB_img = pygame.image.load("invisible.png")
    botaoC_img = pygame.image.load("invisible.png")
    botaoD_img = pygame.image.load("invisible.png")

    botaoA_pos = pygame.Rect(100, 280, 400, 100)
    botaoB_pos = pygame.Rect(600, 280, 400, 100)
    botaoC_pos = pygame.Rect(120, 390, 400, 100)
    botaoD_pos = pygame.Rect(620, 390, 400, 100)

    botaoA_img = pygame.transform.scale(botaoA_img, (400, 100))
    botaoB_img = pygame.transform.scale(botaoB_img, (400, 100))
    botaoC_img = pygame.transform.scale(botaoC_img, (400, 100))
    botaoD_img = pygame.transform.scale(botaoD_img, (400, 100))

    teladequestao_17.blit(botaoA_img, botaoA_pos)
    teladequestao_17.blit(botaoB_img, botaoB_pos)
    teladequestao_17.blit(botaoC_img, botaoC_pos)
    teladequestao_17.blit(botaoD_img, botaoD_pos)

    global ponto2
    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif event.type == pygame.MOUSEBUTTONDOWN:

                if botaoA_pos.collidepoint(event.pos):
                    c.play()
                    ponto2 += 10
                    questao18()

                elif botaoB_pos.collidepoint(event.pos):
                    erro()

                elif botaoC_pos.collidepoint(event.pos):
                    erro()

                elif botaoD_pos.collidepoint(event.pos):
                    erro()

        pygame.display.update()


def questao18():
    teladequestao_18 = pygame.display.set_mode((Largura, Altura))
    pygame.display.set_caption("questão 18")

    imagem = pygame.image.load("perguntas/18.png")
    imagem = pygame.transform.scale(imagem, (Largura, Altura))

    teladequestao_18.blit(imagem, (0, 0))

    botaoA_img = pygame.image.load("invisible.png")
    botaoB_img = pygame.image.load("invisible.png")
    botaoC_img = pygame.image.load("invisible.png")
    botaoD_img = pygame.image.load("invisible.png")

    botaoA_pos = pygame.Rect(100, 280, 400, 100)
    botaoB_pos = pygame.Rect(600, 280, 400, 100)
    botaoC_pos = pygame.Rect(120, 390, 400, 100)
    botaoD_pos = pygame.Rect(620, 390, 400, 100)

    botaoA_img = pygame.transform.scale(botaoA_img, (400, 100))
    botaoB_img = pygame.transform.scale(botaoB_img, (400, 100))
    botaoC_img = pygame.transform.scale(botaoC_img, (400, 100))
    botaoD_img = pygame.transform.scale(botaoD_img, (400, 100))

    teladequestao_18.blit(botaoA_img, botaoA_pos)
    teladequestao_18.blit(botaoB_img, botaoB_pos)
    teladequestao_18.blit(botaoC_img, botaoC_pos)
    teladequestao_18.blit(botaoD_img, botaoD_pos)

    global ponto2

    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif event.type == pygame.MOUSEBUTTONDOWN:

                if botaoA_pos.collidepoint(event.pos):
                    c.play()
                    ponto2 += 10
                    final2()

                elif botaoB_pos.collidepoint(event.pos):
                    erro()
                    # correto

                elif botaoC_pos.collidepoint(event.pos):
                    erro()

                elif botaoD_pos.collidepoint(event.pos):
                    erro()

        pygame.display.update()


janela1()
pygame.display.update()